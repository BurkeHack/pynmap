Simple herramienta en Python de escaneo de puertos utilizando técnicas básicas de evasión e imprimiendo los resultados en una tabla.

Instalación: pip -r requirements.txt

Uso: python3 pynmap.py [IP]
