import nmap
import argparse
from tabulate import tabulate

# Crear objeto NmapScanner
nm = nmap.PortScanner()

# Crear objeto ArgumentParser
parser = argparse.ArgumentParser(description='Escanear una red utilizando nmap')

# Agregar argumento de dirección IP
parser.add_argument('ip_range', metavar='Rango-IP', type=str, help='Rango de dirección IP a escanear')
# Agregar argumento de verbosidad
parser.add_argument('-v', '--verbose', action='store_true', help='Mostrar resultados detallados')

# Analizar argumentos de línea de comandos
args = parser.parse_args()

# Lista de puertos comunes a escanear
common_ports = '1-1023'

# Ejecutar el escaneo con técnicas de evasión y detección de versiones
nm.scan(args.ip_range, arguments=f'-sS -sU -T4 -O -p {common_ports} -vv -f -D RND:10 -sV')

# Crear una lista para almacenar los datos de los hosts
host_data = []

# Recorrer todos los hosts escaneados
for host in nm.all_hosts():
    host_services = []
    # Recorrer todos los servicios detectados en cada host
    for protocol in nm[host].all_protocols():
        ports = sorted(nm[host][protocol].keys())
        for port in ports:
            # Verificar si el puerto está en la lista de puertos comunes
            if port <= 1023:
                service_name = nm[host][protocol][port]['name']
                service_version = nm[host][protocol][port]['version'] if 'version' in nm[host][protocol][port] else ''
                # Almacenar el puerto, protocolo y servicio en una lista
                host_services.append([f'{port}/{protocol}', service_name, service_version])
    # Verificar si se encontró información del sistema operativo
    os_name = nm[host]['osmatch'][0]['name'] if 'osmatch' in nm[host] else 'Desconocido'
    # Agregar información del host y sus servicios a la lista de datos
    host_data.append([host, nm[host]['status']['state'], os_name, '', '', ''])
    for service in host_services:
        host_data.append(['', '', '', service[0], service[1], service[2]])

# Imprimir tabla con los datos
if args.verbose:
    print(tabulate(host_data, headers=['Dirección IP', 'Estado', 'Sistema operativo', 'Puerto/Protocolo', 'Servicios', 'Versión']))
else:
    print(tabulate(host_data, headers=['Dirección IP', 'Estado', 'Sistema operativo', 'Puerto/Protocolo', 'Servicios']))
